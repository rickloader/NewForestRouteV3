Model : BR exLNER 1st Type Fish Van
Version: 3.0
Released : 09/11/2003
Author : Model by Ian Morgan
Skin : Ian Macmillan.

This model is for your personal use only, and may not be sold or distributed in any way without the author's permission.

HISTORY
~~~~~~~
This was the first design of fish van built by the LNER and was based on a GNR design. These vans were replaced by faster wagons and ended up downgraded to ordinary goods.

INSTALLATION
~~~~~~~~~~~~
Before installing any models, I suggest you make a copy of all the files in the 
\TRAINS\TRAINSET directory - failure to do this may result in a lengthy re-installation process.

Unzip to tenporary folder and copy, move or drag to your Trainsets folder

You are now ready to create a consist containing this model by using the Activity Editor
supplied with Microsoft Train Simulator - the model will not be available in the simulator unless you do this.



WARNING: It is not recommended that you delete these files once installed.